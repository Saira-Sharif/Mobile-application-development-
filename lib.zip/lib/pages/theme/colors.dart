import 'dart:ui';
import 'package:flutter/material.dart';


const primaryColor = Color(0xff5ABD8C);
const secondaryColor = Color(0xff00ff0d);
const backgroundColor = Color(0xffffffff);
const fontColor = Color(0xff000000);
const labelColor = Color(0xff686868);
